using Microsoft.VisualBasic.ApplicationServices;
using WinFormsApp2.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormsApp2.Fragments;

namespace WinFormsApp2

{
    public partial class Form1 : Form
    {
        Dictionary<string, User> allUsers = new Dictionary<string, User>();
        public Form1()
        {
            InitializeComponent();

            ClearLoginForm();

        }

        public void ClearLoginForm()
        {
            LoginUserControl luc = this.loginUserControl1;

            luc.ClearAllTextBox();
        }


        public void RegisterUser(string firstName, string middleName, string lastName, string email, string password, string confirmPassword)
        {
            User newUser = new User();

            newUser.FirstName = firstName;
            newUser.MiddleName = middleName;
            newUser.LastName = lastName;
            newUser.Email = email;
            newUser.Password = password;

            if (allUsers.ContainsKey(email))
            {
                MessageBox.Show("Email is taken");
            }
            else if (!password.Equals(confirmPassword))
            {
                MessageBox.Show("Password doesnt match");
            }
            else
            {
                allUsers.Add(email, newUser);
                MessageBox.Show("Registered User");
                showLoginForm();
            }
        }

        public void LoginUser(string email, string password)
        {
            if (allUsers.ContainsKey(email) && allUsers[email].Password.Equals(password))
            {
                Form2 newForm2 = new Form2(email, allUsers[email].FirstName, allUsers[email].LastName);
                newForm2.Show();
                ClearLoginForm();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid Input");
            }
        }

        public void showLoginForm()
        {
            registerControl2.Hide();
            loginUserControl1.Show();
        }

        public void showRegisterForm()
        {
            registerControl2.Show();
            loginUserControl1.Hide();

            RegisterControl rc = registerControl2;
            rc.ClearAllTextBox();
        }

        private void loginControl1_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void registerControl2_Load(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}





