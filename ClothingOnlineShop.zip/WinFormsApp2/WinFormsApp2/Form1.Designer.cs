﻿namespace WinFormsApp2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            registerControl2 = new RegisterControl();
            loginUserControl1 = new Fragments.LoginUserControl();
            SuspendLayout();
            // 
            // registerControl2
            // 
            registerControl2.BackColor = Color.FromArgb(255, 192, 255);
            registerControl2.Location = new Point(315, 12);
            registerControl2.Name = "registerControl2";
            registerControl2.Size = new Size(364, 473);
            registerControl2.TabIndex = 3;
            registerControl2.UseWaitCursor = true;
            registerControl2.Load += registerControl2_Load;
            // 
            // loginUserControl1
            // 
            loginUserControl1.Location = new Point(315, 12);
            loginUserControl1.Name = "loginUserControl1";
            loginUserControl1.Size = new Size(364, 473);
            loginUserControl1.TabIndex = 4;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(916, 489);
            Controls.Add(loginUserControl1);
            Controls.Add(registerControl2);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
        }

        #endregion
        private RegisterControl registerControl2;
        private Fragments.LoginUserControl loginUserControl1;
    }
}