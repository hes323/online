﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormsApp2.Fragments;

namespace WinFormsApp2
{
    public partial class Form2 : Form
    {
        Dictionary<string, User> allUser = new Dictionary<string, User>();
        string email = "";

        public Form2(string email, string firstName, string lastName)
        {
            InitializeComponent();
            this.email = email;
            setNameForm2(firstName, lastName);
            dashBoardControl1.Show();
            exploreControl1.Hide();
            menItemControl1.Hide();
            ladiesControl1.Hide();
            kidControl1.Hide();
            cart1.Hide();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        public void showHome()
        {
            cart1.Hide();
            dashBoardControl1.Show();
            exploreControl1.Hide();
            menItemControl1.Hide();
            ladiesControl1.Hide();
            kidControl1.Hide();
        }

        public void showExplore()
        {
            cart1.Hide();
            dashBoardControl1.Hide();
            exploreControl1.Show();
            menItemControl1.Hide();
            ladiesControl1.Hide();
            kidControl1.Hide();
        }

        public void showMen()
        {
            cart1.Hide();
            dashBoardControl1.Hide();
            exploreControl1.Hide();
            menItemControl1.Show();
            ladiesControl1.Hide();
            kidControl1.Hide();
        }

        public void showLadies()
        {
            cart1.Hide();
            dashBoardControl1.Hide();
            exploreControl1.Hide();
            menItemControl1.Hide();
            ladiesControl1.Show();
            kidControl1.Hide();
        }

        public void showKid()
        {
            cart1.Hide();
            dashBoardControl1.Hide();
            exploreControl1.Hide();
            menItemControl1.Hide();
            ladiesControl1.Hide();
            kidControl1.Show();
        }

        public void showCart()
        {
            cart1.Show();
            dashBoardControl1.Hide();
            exploreControl1.Hide();
            menItemControl1.Hide();
            ladiesControl1.Hide();
            kidControl1.Hide();
        }

        public void addItemToCard(Image image, string itemName, string itemPrice)
        {
            CartControl cc = this.cart1;
            cc.addItemCart(image, itemName,itemPrice);

        }

        public void setNameForm2(string firstName, string lastName)
        {
            DashBoardControl db = this.dashBoardControl1;

            db.setName(firstName, lastName);
        }

        public void setUserProperty(string firtName, string middleName, string lastName, string email, string password)
        {
            User newUser = new User();
            newUser.FirstName = firtName;
            newUser.MiddleName = middleName;
            newUser.LastName = lastName;
            newUser.Email = email;
            newUser.Password = password;

            allUser.Add(email, newUser);


        }

        public void LogoutUser()
        {
            Form1 form1 = new Form1();
            form1.ClearLoginForm();
            this.Hide();
        }


    }
}
