﻿namespace WinFormsApp2
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dashBoardControl1 = new DashBoardControl();
            exploreControl1 = new ExploreControl();
            menItemControl1 = new MenItemControl();
            kidControl1 = new KidControl();
            ladiesControl1 = new LadiesControl();
            cart1 = new Fragments.CartControl();
            SuspendLayout();
            // 
            // dashBoardControl1
            // 
            dashBoardControl1.BackColor = Color.White;
            dashBoardControl1.BackgroundImageLayout = ImageLayout.Stretch;
            dashBoardControl1.Location = new Point(-6, 2);
            dashBoardControl1.Name = "dashBoardControl1";
            dashBoardControl1.Size = new Size(954, 497);
            dashBoardControl1.TabIndex = 0;
            // 
            // exploreControl1
            // 
            exploreControl1.AutoScroll = true;
            exploreControl1.Location = new Point(-6, 2);
            exploreControl1.Name = "exploreControl1";
            exploreControl1.Size = new Size(944, 458);
            exploreControl1.TabIndex = 1;
            // 
            // menItemControl1
            // 
            menItemControl1.BackColor = Color.White;
            menItemControl1.Font = new Font("Segoe UI", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            menItemControl1.Location = new Point(-4, 2);
            menItemControl1.Name = "menItemControl1";
            menItemControl1.Size = new Size(931, 488);
            menItemControl1.TabIndex = 2;
            // 
            // kidControl1
            // 
            kidControl1.Location = new Point(-5, -8);
            kidControl1.Name = "kidControl1";
            kidControl1.Size = new Size(932, 479);
            kidControl1.TabIndex = 3;
            // 
            // ladiesControl1
            // 
            ladiesControl1.Location = new Point(-5, 2);
            ladiesControl1.Name = "ladiesControl1";
            ladiesControl1.Size = new Size(936, 478);
            ladiesControl1.TabIndex = 4;
            // 
            // cart1
            // 
            cart1.Location = new Point(-6, 2);
            cart1.Name = "cart1";
            cart1.Size = new Size(944, 458);
            cart1.TabIndex = 5;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(938, 460);
            Controls.Add(menItemControl1);
            Controls.Add(dashBoardControl1);
            Controls.Add(exploreControl1);
            Controls.Add(ladiesControl1);
            Controls.Add(kidControl1);
            Controls.Add(cart1);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            ResumeLayout(false);
        }

        #endregion

        private DashBoardControl dashBoardControl1;
        private ExploreControl exploreControl1;
        private MenItemControl menItemControl1;
        private KidControl kidControl1;
        private LadiesControl ladiesControl1;
        private Fragments.CartControl cart1;
    }
}